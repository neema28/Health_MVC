//package com.nt.enums;
//
//public enum Gender {
//	MALE, FEMALE, OTHER
//}