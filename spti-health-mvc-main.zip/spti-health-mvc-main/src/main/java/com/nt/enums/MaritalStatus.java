//package com.nt.enums;
//
//public enum MaritalStatus {
//	SINGLE, MARRIED, DIVORCED, WIDOWED
//}
