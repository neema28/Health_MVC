//package com.nt.Dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//public class DoctorSpecializationDto {
//	private Long id;
//	private String title;
//}
