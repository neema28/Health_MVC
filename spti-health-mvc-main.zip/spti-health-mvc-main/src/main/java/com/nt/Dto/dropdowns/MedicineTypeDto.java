//package com.nt.Dto.dropdowns;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//public class MedicineTypeDto {
//	private int id;
//	private String type;
//
//}
