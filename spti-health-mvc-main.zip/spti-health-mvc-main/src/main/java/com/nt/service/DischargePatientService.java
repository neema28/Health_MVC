package com.nt.service;

import com.nt.Dto.patients.DischargePatientRequestDto;

public interface DischargePatientService {

	String dischargePatient(DischargePatientRequestDto dto);

}
